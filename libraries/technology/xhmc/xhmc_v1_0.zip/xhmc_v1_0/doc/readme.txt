1. First IP drop for VIVADO 2016.1
2. IP license enabled

04/14/2016
1. Fixed CSR domain crossing bug
2. Add reference clock configuration
3. enable hardware timeout for evaluation license

04/28/2016
1. Fixed CSR domain crossing bug( read channel)
2. Upgrade MICRON BFM model (Enabled VCS simulation)

05/10/2016
1. Fixed CSR domain crossing bug (read channel, read data offset)
2. Open access for reset control statemachine from csr
3. change default GT insertion loss from 4db to 6 db

05/16/2016
1. Revert the default GT insertion loss back to 4
2. Fix example design pass status issue.
3. Add support for unligned AXI4MM transaction address for the example design.

06/05/2106
1. Move bufg_gt for GT reference clock to IP top 

07/20/2106
1. Add IP option to use single-end reference clock (move bufggt to example design).
2. Enhanced statemachine in the example design to expose debugging information.
3. Change IIC driver in the example design to NACK for the last byte of read
4. Add more device configuration read transactions to allow debugging.
5. Added CSR field to set the device CUBE ID. 

08/09/2016
1. Merged changes for code uniqufication
2. Change Gearbox timing constraint.
